
import { Driver } from '../models/driver';

export const drivers: Driver[] = [];


export interface Driver {
    id?: string;
    name: string;
    team: string;
}
